SIMRING
====

Simulator with ring network
