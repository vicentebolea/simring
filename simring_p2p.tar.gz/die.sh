
 echo Killing another instances of this program
 killall scheduler 
 ssh raven01 killall node
 ssh raven02 killall node
 ssh raven03 killall node
 ssh raven04 killall node
 ssh raven05 killall node
 ssh raven06 killall node
 ssh raven07 killall node
 ssh raven08 killall node
 ssh raven09 killall node
 ssh raven10 killall node
 ssh raven11 killall node
 ssh raven12 killall node
 ssh raven13 killall node
 ssh raven14 killall node
 ssh raven15 killall node
 ssh raven16 killall node
